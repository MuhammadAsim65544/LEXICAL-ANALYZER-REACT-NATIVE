import React, { useState } from 'react';
import {
  Text,
  View,
  StyleSheet,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import { AntDesign } from '@expo/vector-icons';

import filePicker from '../modules/pickFile';

export default function ButtonsContainer({ onClickNext, onClickBack }) {
  return (
    <View style={styles.buttonContainer}>
      <TouchableOpacity
        onPress={onClickBack}
        style={styles.customButton}
        underlayColor="#fff">
        <AntDesign name="arrowleft" size={15} color="#fff" />
        <Text style={styles.buttonText}>Home</Text>
      </TouchableOpacity>
      <TouchableOpacity
        onPress={filePicker}
        style={styles.customButton}
        underlayColor="#fff">
        <Text style={styles.buttonText}>Select File</Text>
        <AntDesign name="filetext1" size={12} color="#fff" />
      </TouchableOpacity>
      <TouchableOpacity
        onPress={onClickNext}
        style={styles.customButton}
        underlayColor="#fff">
        <Text style={styles.buttonText}>NEXT</Text>
        <AntDesign name="arrowright" size={15} color="#fff" />
      </TouchableOpacity>
    </View>
  );
}

const baseButtonStyle = {
  flexDirection: 'row',
  justifyContent: 'center',
  alignItems: 'center',
  height: 35,
  width: 100,
  backgroundColor: '#1d3557',
  borderRadius: 10,
  borderWidth: 1,
  borderColor: '#fff',
};

const styles = StyleSheet.create({
  customButton: {
    ...baseButtonStyle,
  },
  buttonText: {
    color: '#fff',
    textAlign: 'center',
    paddingLeft: 10,
    paddingRight: 5,
    paddingBottom: 3,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
});
