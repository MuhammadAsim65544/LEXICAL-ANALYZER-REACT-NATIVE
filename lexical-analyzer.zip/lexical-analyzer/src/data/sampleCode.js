const sampleCode =
  '// SAMPLE CODE\n/* Your First C++\nProgram */\n\nusing namespace std;\nint main() {\n\tint var;\n\tcout << "Salaam World!";\n\treturn 0;\n}\nvoid fun (int foo) {\n\tlong bar = -123.4e3;\n\tcin>>bar;\n}\n';

export default sampleCode;

/*
// SAMPLE CODE\n\n

/* Your First C++
Program */

/*
using namespace std;\n
int main() {\n
\tint var;
\tstd::cout << "Salaam World!";\n
\treturn 0;\n
}\n\n
void fun(int kuch) {\n
\tint uff;\n
\tcin>>uff;\n
}\n

*/