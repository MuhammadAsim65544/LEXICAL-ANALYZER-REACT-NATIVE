import React, { useState, useContext } from 'react';
import {
  Text,
  View,
  StyleSheet,
  TextInput,
  TouchableOpacity,
} from 'react-native';

import { Context } from '../context/CodeContext';

export default function Fragment1() {
  const { state, updateRawCode, updateState } = useContext(Context);
  const [code, setCode] = useState(state.rawCode);

  const numbers = [];

  var numberOfLineBreaks = (code.match(/\n/g) || []).length + 2;

  numbers.push(<Text style={styles.lineNumber}>{1}</Text>);
  for (let i = 2; i < numberOfLineBreaks; i++) {
    numbers.push(<Text style={styles.lineNumber}>{i}</Text>);
  }

  return (
    <View style={styles.container}>
      <View style={styles.innerContainer}>
        <View
          style={{
            flexDirection: 'row',
          }}>
          <View
            style={{
              backgroundColor: '#1d3557',
              width: 25,
              alignSelf: 'flex-start',
              height: '94.7%',
              marginTop: 10,
              paddingVertical: 10,
              paddingLeft: 5,
              borderRightWidth: 1,
              borderRightColor: '#000',
            }}>
            {numbers}
          </View>
          <TextInput
            value={code}
            onChangeText={(text) => setCode(text)}
            onBlur={() => {
              updateRawCode(code);
              updateState(code);
            }}
            style={styles.playground}
            multiline
            numberOfLines={18}
          />
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    backgroundColor: '#ccc5',
  },
  playground: {
    padding: 7,
    color: '#fff',
    backgroundColor: '#1d3557',
    marginVertical: 10,
    flex: 1,
  },
  lineNumber: {
    color: '#ccc',
  },
});
