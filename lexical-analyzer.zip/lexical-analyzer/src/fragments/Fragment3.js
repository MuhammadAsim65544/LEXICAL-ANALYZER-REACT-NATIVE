import React, { useContext } from 'react';
import {
  Text,
  View,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  FlatList,
} from 'react-native';

export default function Fragment3({ output }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Lexeme Token Pairs</Text>
      <View style={styles.output}>
        <FlatList
          data={output}
          keyExtractor={(item) => item[0]}
          renderItem={({ item }) => {
            return (
              <View style={styles.pair}>
                <Text style={styles.pairTerminal}>{'< '}</Text>
                <Text style={styles.token}>{item[1]}</Text>
                <Text style={styles.pairTerminal}>{' , '}</Text>
                <Text style={styles.lexeme}>{item[0]}</Text>
                <Text style={styles.pairTerminal}>{' >'}</Text>
              </View>
            );
          }}
        />
      </View>
      <Text style={styles.footer}>Ⓒ SmartDevs 2021</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#ccc',
    height: '78%',
    padding: 8,
    marginBottom: 10,
    borderWidth: 1,
    borderRadius: 10,
  },

  title: {
    textAlign: 'center',
    fontSize: 17,
    fontWeight: '600',
    marginBottom: 9,
    color: '#000a',
  },
  output: {
    padding: 15,
    borderWidth: 2,
    borderColor: '#ccc',
    backgroundColor: '#fff7',
    borderRadius: 5,
    height: '87%',
  },
  footer: {
    textAlign: 'center',
    marginTop: 4,
    fontSize: 9,
  },
  pair: {
    flexDirection: 'row',
  },
  pairTerminal: {
    color: '#000',
    fontWeight: '700',
  },
  token: {
    color: '#005c69',
    fontSize: 17,
  },
  lexeme: {
    color: '#a1674a',
  },
});
