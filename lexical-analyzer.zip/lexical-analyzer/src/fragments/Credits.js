import React, { useContext } from 'react';
import {
  Text,
  View,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  FlatList,
} from 'react-native';

export default function Credits() {

  return (
    <View style={styles.container}>
      <Text style={styles.title}>CREDITS</Text>
      <View style={styles.output}>

        <Text style={styles.name}>Muhammad Asim  3956 FBAS/BSCS/F18(B)</Text>
      </View>
      <Text style={styles.footer}>Ⓒ SmartDevs 2021</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#ccc',
    height: '78%',
    padding: 8,
    marginBottom: 10,
    borderWidth: 1,
    borderRadius: 10,
  },

  title: {
    textAlign: 'center',
    fontWeight: '600',
    marginBottom: 9,
    color: '#000a',
    fontSize: 20,
  },
  output: {
    padding: 15,
    borderWidth: 2,
    borderColor: '#ccc',
    backgroundColor: '#1d3557',
    borderRadius: 5,
    height: '87%',
    textAlign: "center",
    alignItems: "center",
    justifyContent: "center",
  },
  footer: {
    textAlign: 'center',
    marginTop: 4,
    fontSize: 9,
  },
  name: {
    color: "#fff",
    fontSize:30,
  }
});
