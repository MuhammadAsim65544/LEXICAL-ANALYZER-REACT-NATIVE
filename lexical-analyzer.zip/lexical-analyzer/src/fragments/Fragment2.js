import React, { useContext } from 'react';
import {
  Text,
  View,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  FlatList,
  ScrollView,
} from 'react-native';

import { Context } from '../context/CodeContext';

export default function Fragment2({ title }) {
  const { state } = useContext(Context);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{title}</Text>
      <ScrollView style={styles.output}>
        <Text>{state.codeState}</Text>
      </ScrollView>
      <Text style={styles.footer}>Ⓒ SmartDevs 2021</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#ccc',
    height: '78%',
    padding: 8,
    marginBottom: 10,
    borderWidth: 1,
    borderRadius: 10,
  },

  title: {
    textAlign: 'center',
    fontWeight: '600',
    marginBottom: 9,
    color: '#000a',
  },
  output: {
    padding: 15,
    borderWidth: 2,
    borderColor: '#ccc',
    backgroundColor: '#fff7',
    borderRadius: 5,
    height: '87%',
  },
  footer: {
    textAlign: 'center',
    marginTop: 4,
    fontSize: 9,
  },
});
