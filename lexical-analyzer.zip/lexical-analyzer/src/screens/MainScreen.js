import React, { useState, useContext } from 'react';
import {
  Text,
  View,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  TouchableWithoutFeedback,
  Keyboard,
} from 'react-native';
import Constants from 'expo-constants';
import { AntDesign } from '@expo/vector-icons';

import Fragment1 from '../fragments/Fragment1';
import Fragment2 from '../fragments/Fragment2';
import Fragment3 from '../fragments/Fragment3';
import Credits from '../fragments/Credits';
import ButtonsContainer from '../components/ButtonsContainer';
import { Context } from '../context/CodeContext';
import generateTokens from '../modules/generateTokens';

export default function MainScreen() {
  const [index, setIndex] = useState(1);
  const [lexTokenPair, setLexTokenPair] = useState([]);

  const { state, updateState } = useContext(Context);

  const RenderElement = () => {
    if (index === 1) {
      return <Fragment1 />;
    } else if (index === 2) {
      return <Fragment2 title="Remove Comments etc." />;
    } else if (index === 3) {
      return <Fragment2 title="Remove Unnecessary Whitespaces" />;
    } else if (index === 4) {
      return <Fragment3 output={lexTokenPair} />;
    } else if (index === 5) {
      return <Credits />;
    }
  };

  const onNext = () => {
    if (index === 1) {
      console.log(/("(?:[^"\\]|\\"|\\)*")/g.exec(state));
      updateState(
        state.codeState.replace(
          /("(?:[^"\\]|\\"|\\)*")|(\/\/.*(?=[\n\r]))|(\/\*(.|\n)+?\*\/)/g, //String, single, block
          ''
        )
      );
    } else if (index === 2) {
      setLexTokenPair(generateTokens(state.codeState));
      updateState(state.codeState.replace(/(\n\t*)/g, ''));
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>LEXICAL ANALYZER</Text>
      <RenderElement />
      <ButtonsContainer
        onClickNext={() => {
          onNext();
          index !== 5 && setIndex(index + 1);
        }}
        onClickBack={() => {
          updateState(state.rawCode);
          setIndex(1);
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ccc5',
    padding: 8,
  },
  title: {
    textAlign: 'center',
    fontSize: 24,
    fontWeight: '700',
  },
});

/*



 */
