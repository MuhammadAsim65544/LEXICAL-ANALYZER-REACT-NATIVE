import createDataContext from './createDataContext';
import sampleCode from '../data/sampleCode';

const blogReducer = (state, action) => {
  switch (action.type) {
    case 'UPD_STATE':
      return {
        codeState: action.payload,
        rawCode: state.rawCode,
      };
    case 'UPD_RAW_CODE':
      return {
        codeState: state.codeState,
        rawCode: action.payload,
      };
    default:
      return state;
  }
};

const updateState = (dispatch) => {
  return (state) => {
    dispatch({ type: 'UPD_STATE', payload: state });
  };
};

const updateRawCode = (dispatch) => {
  return (state) => {
    dispatch({ type: 'UPD_RAW_CODE', payload: state });
  };
};

export const { Context, Provider } = createDataContext(
  blogReducer,
  { updateState, updateRawCode },
  { rawCode: sampleCode, codeState: sampleCode }
);

/*


*/
