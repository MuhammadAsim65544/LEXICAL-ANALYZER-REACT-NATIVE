import keywords from '../data/keywords';

function isKeyword(token) {
  for (let i = 0; i < keywords.length; i++) {
    if (keywords[i] === token) {
      return true;
    }
  }
  return false;
}

const generateTokenList = (code) => {
  var lexTokenList = [];

  //regex
  const checkIfAlphNum = /^[a-z0-9]+$/i;
  const checkIfValidId = /^[_$a-zA-Z\xA0-\uFFFF][_$a-zA-Z0-9\xA0-\uFFFF]*$/i;

  //helping vars
  var tempToken = '',
    ch,
    specialSymbols = '"+-*/%=#<>;:{}()',
    tempSymbols = '.-#:$@^_';

  //loop control vars
  var i,
    k = 0;

  while (k < code.length) {
    ch = code.charAt(k++);

    if (specialSymbols.includes(ch)) {
      lexTokenList.push(['Special Symbol', ch]);
    }

    if (tempSymbols.includes(ch) || checkIfAlphNum.test(ch)) {
      //if space or anything else
      tempToken = tempToken.concat(ch);
    } else if (tempToken.length !== 0) {
      if (!isNaN(tempToken)) {
        //is Not a Number
        lexTokenList.push(['NumericConstant', tempToken]);
      } else if (isKeyword(tempToken)) {
        lexTokenList.push(['Keyword', tempToken]);
      } else {
        if (checkIfValidId.test(tempToken)) {
          lexTokenList.push(['Valid_Identifier', tempToken]);
        } else {
          lexTokenList.push(['Invalid_Identifier', tempToken]);
        }
      }
      tempToken = '';
    }
  }
  return lexTokenList;
};
export default generateTokenList;
