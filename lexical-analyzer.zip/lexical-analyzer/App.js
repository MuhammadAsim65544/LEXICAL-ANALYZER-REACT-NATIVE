import React from 'react';

import { Provider } from './src/context/CodeContext';
import MainScreen from './src/screens/MainScreen';

export default function App() {
  return (
    <Provider>
      <MainScreen />
    </Provider>
  );
}
